package com.ejemploFanny.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

//El restController se usa para devolver datos en formato JSON
@RestController
public class Controller {
    
    @GetMapping("/saludar/{name}")
    public String controlador(@PathVariable String name){

        return "Hola desde el controlador " + name;
    }

    @GetMapping("/saludar")
    public String saludarDefault() {
        return "Hola (sin nombre)";
    }

    @GetMapping("/ejercicio/{palabra}")
    public String palindromo(@PathVariable String palabra){
         
        int longitud = palabra.length(); 

        palabra = palabra.toLowerCase();
        
         int j = longitud -1 ;
         
        for(int i = 0; i < longitud;){
               
                
                char letra;
                letra = palabra.charAt(i);
                System.out.println("i = " + letra);

                char letraj;
                letraj = palabra.charAt(j);
                System.out.println("j = " +letraj);
                
                if(i >= j){
                    System.out.println("Es palindromo");
                    return "La palabra " + palabra+ " es palindromo";
                    
                }
                
                if(palabra.charAt(i) == palabra.charAt(j)){
                        i++;
                        j--;
                }
                else{
                    System.out.println("No es palindromo");
                    return "La palabra " + palabra+ " no es palindromo";
                }  
        }
        return "fuera"; 
    } 
        

}

// @pathVariable lee los datos que estan en la URL
