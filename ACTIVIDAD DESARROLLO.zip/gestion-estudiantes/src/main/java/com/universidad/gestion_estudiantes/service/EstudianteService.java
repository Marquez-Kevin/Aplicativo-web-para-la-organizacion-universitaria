// Archivo: src/main/java/com/universidad/gestion_estudiantes/service/EstudianteService.java
package com.universidad.gestion_estudiantes.service;

import com.universidad.gestion_estudiantes.model.Estudiante;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService {

    private final List<Estudiante> estudiantes = new ArrayList<>();
    private Long nextId = 101L;

    public EstudianteService() {
        estudiantes.add(new Estudiante(nextId++, "Ana García", 20));
        estudiantes.add(new Estudiante(nextId++, "Luis Pérez", 22));
    }
    
    public Estudiante guardarEstudiante(Estudiante nuevoEstudiante) {
        nuevoEstudiante.setId(nextId++);
        estudiantes.add(nuevoEstudiante);
        return nuevoEstudiante;
    }

    public List<Estudiante> obtenerTodos() {
        return estudiantes;
    }

    public Optional<Estudiante> obtenerPorId(Long id) {
        return estudiantes.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst();
    }

    public Optional<Estudiante> actualizarEstudiante(Long id, Estudiante datosActualizados) {
        return obtenerPorId(id).map(estudianteExistente -> {
            estudianteExistente.setNombre(datosActualizados.getNombre());
            estudianteExistente.setEdad(datosActualizados.getEdad());
            return estudianteExistente;
        });
    }

    public boolean eliminarEstudiante(Long id) {
        return estudiantes.removeIf(e -> e.getId().equals(id));
    }
}